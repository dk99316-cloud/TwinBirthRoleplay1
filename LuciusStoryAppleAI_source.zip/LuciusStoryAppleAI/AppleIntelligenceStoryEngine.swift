import Foundation
import Combine
import FoundationModels

// MARK: - Local Mushoku Tensei knowledge tool

struct MushokuKnowledgeTool: Tool {
    let name = "searchStoryKnowledge"
    let description = "앱에 저장된 무직전생 IF 세계관, 인물 관계, 진행 규칙, 연표 메모를 검색한다. 대화의 연속성을 유지하기 위해 먼저 사용할 가치가 높다."

    @Generable
    struct Arguments {
        @Guide(description: "찾고 싶은 인물, 사건, 관계, 설정 또는 키워드")
        var query: String
    }

    func call(arguments: Arguments) async throws -> String {
        let query = arguments.query.lowercased()
        let entries = Self.entries + Self.bundledEntries
        let terms = query.split(whereSeparator: { $0.isWhitespace }).map(String.init)
        let ranked = entries.map { entry -> (Int, String) in
            let haystack = (entry.title + " " + entry.body).lowercased()
            let score = terms.reduce(0) { partial, term in
                partial + (haystack.contains(term) ? 2 : 0)
            }
            return (score, entry.text)
        }.filter { $0.0 > 0 }.sorted { $0.0 > $1.0 }
        if ranked.isEmpty { return "앱에 저장된 오프라인 세계관 자료에서 관련 내용을 찾지 못했습니다." }
        return ranked.prefix(4).map { String($0.1.prefix(450)) }.joined(separator: "\n\n")
    }

    private struct Entry {
        let title: String
        let body: String
        var text: String { "[\(title)]\n\(body)" }
    }

    private static let entries: [Entry] = [
        Entry(title: "루데우스", body: "루데우스는 루시우스의 쌍둥이 형이다. 두 아이의 첫 번째 삶이며 전생이나 이전 삶의 기억이 없다."),
        Entry(title: "루시우스", body: "루시우스는 루데우스의 쌍둥이 동생이다. 사용자가 직접 연기한다. AI는 루시우스의 행동, 대사, 생각, 감정을 임의로 만들지 않는다."),
        Entry(title: "탄생 장면", body: "이야기는 루데우스와 루시우스가 태어난 직후부터 시작한다. 파울로와 제니스는 살아 있다. 신생아는 말하거나 걷거나 의식적인 행동을 하지 않는다."),
        Entry(title: "실피", body: "실피는 이야기 속 인물이다. 실피나 다른 인물도 미래 기억을 갖지 않는다."),
        Entry(title: "역할극 규칙", body: "사용자는 루시우스만 직접 조작한다. AI는 다른 인물과 세계의 반응만 쓴다. 최신 입력에 직접 반응하고 장면을 반복하지 않는다."),
        Entry(title: "오프라인 동작", body: "이 앱은 Apple Foundation Models와 앱 안에 저장된 설정 자료만 사용한다. 이야기 생성 중 네트워크 검색이나 서버 요청을 하지 않는다."),
    ]

    private static let bundledEntries: [Entry] = {
        guard let url = Bundle.main.url(forResource: "offline_story_knowledge", withExtension: "txt"),
              let text = try? String(contentsOf: url, encoding: .utf8) else { return [] }
        return text.components(separatedBy: "\n\n")
            .map { $0.trimmingCharacters(in: .whitespacesAndNewlines) }
            .filter { !$0.isEmpty }
            .enumerated()
            .map { Entry(title: "저장 설정 \($0.offset + 1)", body: $0.element) }
    }()
}

// MARK: - Persistent long-term memory

struct StoryMemory: Codable {
    var summary: String = "아직 장기 기억이 없습니다."
    var importantFacts: [String] = []
    var relationshipNotes: [String] = []
    var currentScene: String = ""
    var lastCompactedMessageCount: Int = 0
}

@MainActor
final class StoryMemoryStore: ObservableObject {
    @Published private(set) var memory: StoryMemory
    private let key = "LuciusStory.longTermMemory.v2"

    init() {
        if let data = UserDefaults.standard.data(forKey: key),
           let saved = try? JSONDecoder().decode(StoryMemory.self, from: data) {
            memory = saved
        } else {
            memory = StoryMemory()
        }
    }

    func update(_ newMemory: StoryMemory) {
        memory = newMemory
        if let data = try? JSONEncoder().encode(newMemory) {
            UserDefaults.standard.set(data, forKey: key)
        }
    }

    func clear() {
        update(StoryMemory())
    }

    /// 사용자가 과거 대화를 수정하거나 삭제하면 기존 요약이 오래된 내용일 수 있으므로
    /// 다음 대화 후 장기 기억을 다시 압축하도록 표시한다.
    func markNeedsRefresh() {
        memory.lastCompactedMessageCount = -1
        persist()
    }

    private func persist() {
        if let data = try? JSONEncoder().encode(memory) {
            UserDefaults.standard.set(data, forKey: key)
        }
    }
}

@MainActor
final class AppleIntelligenceStoryEngine: ObservableObject {
    @Published private(set) var isGenerating = false
    @Published private(set) var status = "확인 중"
    @Published private(set) var errorMessage: String?

    private let model = SystemLanguageModel.default
    private let memoryStore: StoryMemoryStore

    private let instructions = """
    당신은 '루시우스의 이야기'의 세계 진행 AI다.

    핵심 규칙:
    1. 사용자는 루시우스의 행동, 대사, 생각을 직접 결정한다. 절대로 루시우스의 행동·대사·생각·감정을 대신 만들거나 수정하지 않는다.
    2. AI는 루시우스를 제외한 등장인물과 세계의 반응만 작성한다.
    3. 최신 사용자 입력을 현재 턴의 직접적인 원인으로 취급한다. 최신 입력과 무관한 이전 장면을 반복하지 않는다.
    4. 같은 문장이나 문단을 반복하지 않는다.
    5. 장기 기억과 오프라인 검색 결과를 현재 장면보다 우선하지 말고, 서로 충돌하면 가장 최근의 명시적 사용자 설정을 따른다.
    6. 앱에 포함된 오프라인 설정 자료만 참고한다. 외부 검색이나 네트워크 요청을 하지 않는다.
    7. 사용자가 짧게 말해도 그 말에 자연스럽게 반응한다.
    8. 한국어로만 답한다.
    9. 사용자가 입력하지 않은 루시우스의 행동이나 대사를 서술하지 않는다.
    10. 메타 설명, AI라는 사실, 프롬프트 규칙을 이야기 안에서 언급하지 않는다.
    """

    init(memoryStore: StoryMemoryStore = StoryMemoryStore()) {
        self.memoryStore = memoryStore
        refreshAvailability()
    }

    var isAvailable: Bool {
        if case .available = model.availability { return true }
        return false
    }

    func refreshAvailability() {
        switch model.availability {
        case .available:
            if model.supportsLocale(Locale(identifier: "ko-KR")) {
                status = "Apple Intelligence 사용 가능"
            } else {
                status = "모델은 준비됐지만 한국어 지원을 확인할 수 없습니다"
            }
        case .unavailable(.deviceNotEligible):
            status = "이 기기는 Apple Intelligence를 지원하지 않습니다"
        case .unavailable(.modelNotReady):
            status = "Apple Intelligence 모델 준비 중"
        case .unavailable:
            status = "Apple Intelligence를 사용할 수 없습니다"
        @unknown default:
            status = "Apple Intelligence 상태 확인 필요"
        }
    }

    func generate(userInput: String, recentHistory: [StoryMessage]) async -> String? {
        errorMessage = nil
        guard !isGenerating else { return nil }
        guard isAvailable else { refreshAvailability(); errorMessage = status; return nil }
        guard model.supportsLocale(Locale(identifier: "ko-KR")) else {
            errorMessage = "현재 기기의 Apple Intelligence에서 한국어 사용을 지원하지 않습니다."
            return nil
        }

        isGenerating = true
        defer { isGenerating = false }

        let memory = memoryStore.memory
        let context = buildContext(from: recentHistory, memory: memory)
        let prompt = """
        다음은 현재 장면을 이어가기 위해 필요한 장기 기억과 최근 문맥이다.
        --- 장기 기억 ---
        \(memory.summary)
        중요한 사실: \(memory.importantFacts.joined(separator: " | "))
        관계 메모: \(memory.relationshipNotes.joined(separator: " | "))
        현재 장면: \(memory.currentScene)
        --- 장기 기억 끝 ---

        --- 최근 문맥 ---
        \(context)
        --- 최근 문맥 끝 ---

        이제 사용자가 루시우스에게 다음 입력을 했다.
        --- 최신 사용자 입력 ---
        \(userInput)
        --- 최신 사용자 입력 끝 ---
        저장된 세계관 정보가 필요하면 searchStoryKnowledge 도구로 앱 안의 오프라인 자료를 검색하라.
        네트워크, 웹 검색, 외부 서버를 사용하지 않는다.
        반드시 최신 사용자 입력에 직접 반응해서 다음 장면을 작성하라.
        """

        do {
            let session = LanguageModelSession(
                tools: [MushokuKnowledgeTool()],
                instructions: instructions
            )
            session.prewarm()
            let response = try await session.respond(
                to: prompt,
                options: GenerationOptions(maximumResponseTokens: 350, toolCallingMode: .allowed)
            )
            let cleaned = clean(response.content)
            guard !cleaned.isEmpty else {
                errorMessage = "AI가 빈 응답을 반환했습니다."
                return nil
            }
            return cleaned
        } catch {
            errorMessage = readableError(error)
            return nil
        }
    }

    func compactMemory(from history: [StoryMessage]) async {
        guard isAvailable, history.count >= 6 else { return }
        let oldMemory = memoryStore.memory
        let recent = history.suffix(10).map { message in
            let role = message.role == .user ? "루시우스/사용자" : message.role == .assistant ? "NPC/세계" : "설정"
            return "[\(role)] \(String(message.text.suffix(300)))"
        }.joined(separator: "\n")

        let prompt = """
        너는 장기 기억 정리 담당자다. 아래 기존 기억과 최근 대화를 보고, 다음 장면에서도 반드시 기억해야 할 내용만 압축하라.
        새로 만들어내지 말고 대화에서 확인된 사실만 기록한다. 루시우스의 행동을 추측하지 않는다.

        기존 기억:
        요약: \(String(oldMemory.summary.suffix(400)))
        중요 사실: \(oldMemory.importantFacts.map { String($0.suffix(120)) }.joined(separator: " | "))
        관계: \(oldMemory.relationshipNotes.map { String($0.suffix(120)) }.joined(separator: " | "))
        장면: \(String(oldMemory.currentScene.suffix(250)))

        최근 대화:
        \(recent)

        다음 형식으로 한국어로만 답한다.
        SUMMARY: 한 문단
        FACTS: 사실1 || 사실2 || 사실3
        RELATIONSHIPS: 관계1 || 관계2
        SCENE: 현재 장면 한 줄
        """

        do {
            let session = LanguageModelSession(instructions: "당신은 이야기의 장기 기억을 정확하게 압축하는 기록 담당자다.")
            let response = try await session.respond(to: prompt)
            var parsed = parseMemory(response.content, base: oldMemory)
            guard !parsed.summary.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty else { return }
            parsed.lastCompactedMessageCount = history.count
            memoryStore.update(parsed)
        } catch {
            // 기억 압축 실패는 이야기 진행을 막지 않는다.
        }
    }

    private func parseMemory(_ text: String, base: StoryMemory) -> StoryMemory {
        var result = base
        let lines = text.components(separatedBy: .newlines)
        for line in lines {
            if line.hasPrefix("SUMMARY:") {
                result.summary = String(line.dropFirst("SUMMARY:".count)).trimmingCharacters(in: .whitespaces)
            } else if line.hasPrefix("FACTS:") {
                result.importantFacts = splitMemory(String(line.dropFirst("FACTS:".count)))
            } else if line.hasPrefix("RELATIONSHIPS:") {
                result.relationshipNotes = splitMemory(String(line.dropFirst("RELATIONSHIPS:".count)))
            } else if line.hasPrefix("SCENE:") {
                result.currentScene = String(line.dropFirst("SCENE:".count)).trimmingCharacters(in: .whitespaces)
            }
        }
        return result
    }

    private func splitMemory(_ value: String) -> [String] {
        value.components(separatedBy: "||")
            .map { $0.trimmingCharacters(in: .whitespacesAndNewlines) }
            .filter { !$0.isEmpty }
            .prefix(8).map(String.init)
    }

    private func buildContext(from history: [StoryMessage], memory: StoryMemory) -> String {
        let recent = history.suffix(4)
        var text = recent.map { message in
            let speaker: String
            switch message.role {
            case .user: speaker = "사용자/루시우스"
            case .assistant: speaker = "세계/NPC"
            case .system: speaker = "설정"
            }
            return "[\(speaker)] \(String(message.text.suffix(300)))"
        }.joined(separator: "\n")
        if text.count > 1200 { text = String(text.suffix(1200)) }
        return text
    }

    private func clean(_ text: String) -> String {
        let normalizedText = text.replacingOccurrences(of: "\r\n", with: "\n")
        let paragraphs = normalizedText.trimmingCharacters(in: .whitespacesAndNewlines)
            .components(separatedBy: "\n\n")
        var unique: [String] = []
        var seen = Set<String>()
        for paragraph in paragraphs {
            let p = paragraph.trimmingCharacters(in: .whitespacesAndNewlines)
            guard !p.isEmpty else { continue }
            let normalized = p.replacingOccurrences(of: /\s+/, with: " ").lowercased()
            guard !seen.contains(normalized) else { continue }
            seen.insert(normalized)
            unique.append(p)
        }
        return unique.joined(separator: "\n\n")
    }

    private func readableError(_ error: Error) -> String {
        if let modelError = error as? LanguageModelError {
            return "Apple Intelligence 오류: \(modelError)"
        }
        return "AI 생성 오류: \(error.localizedDescription)"
    }
}
