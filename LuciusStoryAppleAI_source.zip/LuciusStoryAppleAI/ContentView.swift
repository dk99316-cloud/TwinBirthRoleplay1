
import SwiftUI
#if canImport(UIKit)
import UIKit
#endif

struct ContentView: View {
    @StateObject private var memoryStore = StoryMemoryStore()
    @StateObject private var engine: AppleIntelligenceStoryEngine
    @State private var messages: [StoryMessage] = []
    @State private var input = ""
    @State private var editingMessageID: UUID?
    @State private var editingText = ""
    @State private var showEditSheet = false
    @State private var showResetConfirmation = false
    @FocusState private var inputFocused: Bool

    private let saveKey = "LuciusStory.messages.v5"

    init() {
        let store = StoryMemoryStore()
        _memoryStore = StateObject(wrappedValue: store)
        _engine = StateObject(wrappedValue: AppleIntelligenceStoryEngine(memoryStore: store))
    }

    private let characters: [(name: String, asset: String)] = [
        ("루시우스", "lucius"),
        ("실피", "sylphie"),
        ("루데우스", "rudeus"),
        ("록시", "roxy"),
        ("에리스", "eris")
    ]

    var body: some View {
        ZStack {
            Image("backdrop")
                .resizable()
                .scaledToFill()
                .ignoresSafeArea()
                .overlay(.black.opacity(0.52))

            VStack(spacing: 0) {
                topBar
                characterFaces
                story
                composer
            }
        }
        .preferredColorScheme(.dark)
        .task {
            load()
            if messages.isEmpty { await startStory() }
        }
        .alert("처음부터 다시 시작할까요?", isPresented: $showResetConfirmation) {
            Button("취소", role: .cancel) { }
            Button("처음부터", role: .destructive) { resetStory() }
        } message: {
            Text("저장된 대화와 장기 기억을 지우고 쌍둥이의 탄생 장면부터 시작합니다.")
        }
    }

    private var topBar: some View {
        HStack {
            VStack(alignment: .leading, spacing: 2) {
                Text("루시우스의 이야기")
                    .font(.title3.bold())
                Text("무직전생 IF")
                    .font(.caption)
                    .foregroundStyle(.white.opacity(0.65))
            }
            Spacer()
            HStack(spacing: 7) {
                Circle()
                    .fill(engine.isAvailable ? Color.green : Color.orange)
                    .frame(width: 7, height: 7)
                Text(engine.isAvailable ? "Apple AI" : "AI 확인")
                    .font(.caption.bold())
                Text("기억 \(memoryStore.memory.importantFacts.count + memoryStore.memory.relationshipNotes.count)")
                    .font(.caption2.bold())
                    .foregroundStyle(.white.opacity(0.7))
            }
            .padding(.horizontal, 10)
            .padding(.vertical, 7)
            .background(.black.opacity(0.45), in: Capsule())

            Menu {
                Button(role: .destructive) {
                    showResetConfirmation = true
                } label: {
                    Label("처음부터", systemImage: "arrow.counterclockwise")
                }
            } label: {
                Image(systemName: "ellipsis.circle")
                    .font(.title2)
                    .foregroundStyle(.white)
                    .padding(.leading, 3)
            }
            .accessibilityLabel("이야기 메뉴")
            .disabled(engine.isGenerating)
        }
        .padding(.horizontal, 14)
        .padding(.top, 10)
        .padding(.bottom, 8)
    }

    private var characterFaces: some View {
        ScrollView(.horizontal, showsIndicators: false) {
            HStack(spacing: 13) {
                ForEach(characters, id: \.name) { character in
                    VStack(spacing: 4) {
                        Image(character.asset)
                            .resizable()
                            .scaledToFill()
                            .frame(width: 72, height: 72)
                            .clipShape(Circle())
                            .overlay(
                                Circle().stroke(.white.opacity(0.7), lineWidth: 2)
                            )
                            .shadow(radius: 8)
                        Text(character.name)
                            .font(.caption.bold())
                    }
                }
            }
            .padding(.horizontal, 14)
            .padding(.vertical, 8)
        }
        .background(.black.opacity(0.28))
    }

    private var story: some View {
        ScrollView {
            LazyVStack(spacing: 12) {
                if messages.isEmpty {
                    VStack(spacing: 12) {
                        Image("sylphie")
                            .resizable()
                            .scaledToFill()
                            .frame(width: 105, height: 105)
                            .clipShape(Circle())
                            .overlay(Circle().stroke(.white.opacity(0.75), lineWidth: 2))

                        Text("실피")
                            .font(.headline.bold())

                        Text("루시우스의 첫 번째 삶. 쌍둥이의 탄생 장면부터 시작합니다.")
                            .font(.subheadline)
                            .multilineTextAlignment(.center)
                            .foregroundStyle(.white.opacity(0.75))

                        if !engine.isGenerating {
                            Button("첫 장면 시작 / 다시 시도") {
                                Task { await startStory() }
                            }
                            .buttonStyle(.borderedProminent)
                        }
                    }
                    .frame(maxWidth: .infinity)
                    .padding(.top, 28)
                }

                ForEach(messages) { message in
                    messageRow(message)
                        .contextMenu {
                            if message.role == .user {
                                Button {
                                    beginEditing(message)
                                } label: {
                                    Label("수정", systemImage: "pencil")
                                }

                                Button(role: .destructive) {
                                    deleteMessage(message)
                                } label: {
                                    Label("삭제", systemImage: "trash")
                                }
                            }
                        }
                }

                if let error = engine.errorMessage {
                    HStack(alignment: .top, spacing: 8) {
                        Image(systemName: "exclamationmark.triangle.fill")
                        Text(error)
                            .font(.caption)
                    }
                    .foregroundStyle(.orange)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding(.horizontal, 12)
                }

                if engine.isGenerating {
                    HStack(spacing: 8) {
                        ProgressView()
                        Text("AI가 반응을 생성하고 있어요…")
                            .font(.caption)
                    }
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding()
                }
            }
            .padding(14)
        }
        .scrollDismissesKeyboard(.interactively)
        .sheet(isPresented: $showEditSheet) {
            editMessageSheet
                .presentationDetents([.medium, .large])
        }
    }

    private func messageRow(_ message: StoryMessage) -> some View {
        let user = message.role == .user
        let character = characters.first(where: { $0.name == "실피" })!

        return HStack(alignment: .top, spacing: 9) {
            if !user {
                Image(character.asset)
                    .resizable()
                    .scaledToFill()
                    .frame(width: 46, height: 46)
                    .clipShape(Circle())
            }

            VStack(alignment: .leading, spacing: 5) {
                Text(user ? "루시우스" : character.name)
                    .font(.caption.bold())
                Text(message.text)
                    .font(.body)
                    .lineSpacing(3)
            }
            .padding(12)
            .background(
                user ? Color.white.opacity(0.9) : Color.black.opacity(0.62),
                in: RoundedRectangle(cornerRadius: 16)
            )
            .foregroundStyle(user ? .black : .white)

            if user { Spacer(minLength: 35) }
        }
    }


    private var editMessageSheet: some View {
        NavigationStack {
            VStack(spacing: 14) {
                Text("사용자 대화 수정")
                    .font(.headline)
                    .frame(maxWidth: .infinity, alignment: .leading)

                TextEditor(text: $editingText)
                    .scrollContentBackground(.hidden)
                    .padding(10)
                    .background(Color.black.opacity(0.08), in: RoundedRectangle(cornerRadius: 14))
                    .frame(minHeight: 180)

                Text("수정하면 기존 장기 기억은 다음 대화에서 다시 정리됩니다.")
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .frame(maxWidth: .infinity, alignment: .leading)
            }
            .padding()
            .navigationTitle("대화 수정")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("취소") { showEditSheet = false }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("저장") { saveEditedMessage() }
                        .disabled(editingText.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                }
            }
        }
    }

    private func beginEditing(_ message: StoryMessage) {
        guard message.role == .user else { return }
        editingMessageID = message.id
        editingText = message.text
        showEditSheet = true
    }

    private func saveEditedMessage() {
        guard let id = editingMessageID,
              let index = messages.firstIndex(where: { $0.id == id }) else {
            showEditSheet = false
            return
        }
        let newText = editingText.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !newText.isEmpty else { return }
        let old = messages[index]
        messages[index] = StoryMessage(id: old.id, role: old.role, text: newText, date: old.date)
        // 수정된 사용자 입력에 대응하는 기존 AI 답변은 더 이상 유효하지 않으므로 제거한다.
        if index + 1 < messages.count, messages[index + 1].role == .assistant {
            messages.remove(at: index + 1)
        }
        memoryStore.markNeedsRefresh()
        save()
        showEditSheet = false
    }

    private func deleteMessage(_ message: StoryMessage) {
        guard message.role == .user, let index = messages.firstIndex(where: { $0.id == message.id }) else { return }
        messages.remove(at: index)
        // 삭제된 사용자 입력 바로 뒤의 AI 답변도 함께 제거해 대화 흐름이 끊기지 않게 한다.
        if index < messages.count, messages[index].role == .assistant {
            messages.remove(at: index)
        }
        memoryStore.markNeedsRefresh()
        save()
    }

    private var composer: some View {
        VStack(spacing: 7) {
            HStack(spacing: 8) {
                TextField("루시우스의 말이나 행동을 입력하세요…", text: $input, axis: .vertical)
                    .lineLimit(1...4)
                    .focused($inputFocused)
                    .submitLabel(.send)
                    .onSubmit { send() }
                    .padding(12)
                    .background(.black.opacity(0.7), in: RoundedRectangle(cornerRadius: 15))
                    .overlay(RoundedRectangle(cornerRadius: 15).stroke(.white.opacity(0.16)))

                Button(action: send) {
                    Image(systemName: engine.isGenerating ? "hourglass" : "paperplane.fill")
                        .frame(width: 48, height: 48)
                        .background(.white, in: Circle())
                        .foregroundStyle(.black)
                }
                .disabled(input.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty || engine.isGenerating)
            }

            Button {
                dismissKeyboard()
            } label: {
                Label("키보드 닫기", systemImage: "keyboard.chevron.compact.down")
                    .font(.caption.bold())
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 8)
                    .background(.white.opacity(0.10), in: Capsule())
            }
        }
        .padding(.horizontal, 12)
        .padding(.top, 8)
        .padding(.bottom, 10)
        .background(.ultraThinMaterial)
    }

    private func send() {
        let text = input.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !text.isEmpty, !engine.isGenerating else { return }

        input = ""
        dismissKeyboard()
        messages.append(StoryMessage(role: .user, text: text))
        save()

        Task {
            if let reply = await engine.generate(userInput: text, recentHistory: messages) {
                messages.append(StoryMessage(role: .assistant, text: reply))
                save()
                if memoryStore.memory.lastCompactedMessageCount < 0 || messages.count - memoryStore.memory.lastCompactedMessageCount >= 8 {
                    await engine.compactMemory(from: messages)
                }
            }
        }
    }

    private func startStory() async {
        guard messages.isEmpty, !engine.isGenerating else { return }
        let opening = "이야기 시작 시점은 루데우스와 루시우스가 쌍둥이로 태어나는 때다. 두 아이는 지금 처음 태어난 것이며 전생이나 이전 삶의 기억이 없다. 실피와 다른 인물도 미래 기억을 가진 상태가 아니다. 루시우스는 신생아로서 의식적인 행동을 하지 않는다. 파울로와 제니스는 살아 있다. 출산을 지켜본 가족의 반응을 묘사하되 루시우스의 감정·생각·행동은 사용자가 직접 정한다."
        let startPrompt = """
        이야기를 처음부터 시작한다. 루데우스와 루시우스의 첫 번째 삶이며 전생이나 이전 삶의 기억이 없다. 두 아이는 이제 막 태어난 신생아다. 부모와 가족의 반응을 짧게 묘사하고, 사용자가 루시우스의 반응을 입력할 차례에 멈춘다.
        \(opening)
        """
        guard let reply = await engine.generate(userInput: startPrompt, recentHistory: []) else { return }
        messages.append(StoryMessage(role: .assistant, text: reply))
        save()
    }

    private func resetStory() {
        messages = []
        memoryStore.clear()
        save()
        Task { await startStory() }
    }
    private func dismissKeyboard() {
        inputFocused = false
        #if canImport(UIKit)
        UIApplication.shared.sendAction(
            #selector(UIResponder.resignFirstResponder),
            to: nil,
            from: nil,
            for: nil
        )
        #endif
    }

    private func load() {
        guard let data = UserDefaults.standard.data(forKey: saveKey),
              let value = try? JSONDecoder().decode([StoryMessage].self, from: data) else { return }
        messages = value
    }

    private func save() {
        if let data = try? JSONEncoder().encode(messages) {
            UserDefaults.standard.set(data, forKey: saveKey)
        }
    }
}
