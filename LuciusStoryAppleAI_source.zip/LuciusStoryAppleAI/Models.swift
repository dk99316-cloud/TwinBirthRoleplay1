import Foundation

struct StoryMessage: Identifiable, Codable, Equatable {
    enum Role: String, Codable { case system, user, assistant }
    let id: UUID
    let role: Role
    let text: String
    let date: Date

    init(id: UUID = UUID(), role: Role, text: String, date: Date = .now) {
        self.id = id
        self.role = role
        self.text = text
        self.date = date
    }
}
